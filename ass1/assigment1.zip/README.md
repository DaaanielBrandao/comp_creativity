The logs are contained within jupyter notebook files

run the following command in this directory:
pip install -r requirements.txt